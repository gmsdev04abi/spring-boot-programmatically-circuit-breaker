package br.com.gmsdev04abi.springbootprogramaticallycircuirtbreaker

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpringBootProgramaticallyCircuirtBreakerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
